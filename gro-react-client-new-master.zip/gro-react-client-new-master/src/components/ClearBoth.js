import React from 'react';

const ClearBoth = () => {
  return <div style={{clear: 'both'}}/>;
};

export default ClearBoth;
