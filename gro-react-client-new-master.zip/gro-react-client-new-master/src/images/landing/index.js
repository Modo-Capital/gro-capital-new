import featuredIn from './featured_in.png';
import howMuchInput from './how_much_input.png';
import investability from './investability.png';
import guidance from './guidance.png';
import fundedCompanies from './funded_companies.png';
import phoneArea from './phone_area.png';
import android from './android.png';
import apple from './apple.png';
import computerArea from './computer_area.png';
import map from './map.png';
import testimonials from './testimonials.png';

export {featuredIn, howMuchInput, investability, guidance, fundedCompanies, phoneArea, android, apple, computerArea, map, testimonials};
