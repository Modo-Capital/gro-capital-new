import clockImg from './clock.png';
import improveImg from './improve.png';
import noCardImg from './no_card.png';
import upToImg from './up_to.png';
import playImg from './play.png';

export { clockImg, improveImg, noCardImg, upToImg, playImg };
