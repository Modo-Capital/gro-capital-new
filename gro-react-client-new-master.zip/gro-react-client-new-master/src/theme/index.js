export const themeVars = {
  fontFamily: "Roboto, serif",
  greyColor: "#BDBDBD",
  greenColor: "#8bc34a",
  lightGreenColor: "#8cc549",
  lightGreyColor: "#d3d3d3",
  lightRedColor: "#d23800",
  lightBlack: "#757575",
  darkerBlack: "#424242"
};
