export const getStartedData = {
  loan_amount_applied: {
    placeholder: 'How much money do you need?',
    options: [
      { value: '25000', label: '$25,000' },
      { value: '50000', label: '$50,000' },
      { value: '75000', label: '$75,000' },
      { value: '100000', label: '$100,000' },
      { value: '150000', label: '$150,000' },
      { value: '200000', label: '$200,000' },
      { value: '300000', label: '$300,000' },
      { value: '500000', label: '$500,000' },
      { value: '0', label: 'Other' }
    ],
    values: {
      25000: '$25,000',
      50000: '$50,000',
      75000: '$75,000',
      100000: '$100,000',
      150000: '$150,000',
      200000: '$200,000',
      300000: '$300,000',
      500000: '$500,000',
      0: 'Other',
    },
  },
  loan_type: {
    placeholder: 'What type of capital are you looking for?',
    options: [
      {
        value: 'line_of_credit',
        label: "Just a line of Credit (I'll be paying Gro back)"
      },
      {
        value: 'equity_investment',
        label: 'Just equity investment (Gro invests in my company)'
      },
      { value: 'either', label: 'Either form of capital' }
    ],
    short: {
      line_of_credit: 'Line of credit',
      equity_investment: 'Equity investment',
      either: 'Either form'
    }
  },
  loan_reason: {
    placeholder: 'What do you need the money for?',
    options: [
      { value: 'marketing', label: 'Advertising and Marketing' },
      { value: 'hiring', label: 'Hiring' },
      { value: 'legal', label: 'Legal and Compliance' },
      { value: 'materials_and_supply', label: 'Materials & Supply' },
      { value: 'product_developmeent', label: 'Product & Development' },
      { value: 'property', label: 'Property' },
      { value: 'acquisition', label: 'Acquisition' },
      { value: 'payroll', label: 'Payroll' },
      { value: 'new_location', label: 'New Location' },
      { value: 'other', label: 'Other' }
    ],
    values: {
      marketing: 'Advertising and Marketing',
      hiring: 'Hiring',
      legal: 'Legal and Compliance',
      materials_and_supply: 'Materials & Supply',
      product_developmeent: 'Product & Development',
      property: 'Property',
      acquisition: 'Acquisition',
      payroll: 'Payroll',
      new_location: 'New Location',
      other: 'Other',
    },
  },
  company_structure: {
    placeholder: 'Company Structure',
    options: [
      { value: 's', label: 'Sole Proprietorship' },
      { value: 'gp', label: 'General Partnership' },
      { value: 'c', label: 'Corporation' },
      { value: 'llc', label: 'LLC' },
      { value: 'sllc', label: 'Single-Member LLC' }
    ]
  },
  industry_type: {
    placeholder: 'Industry Type',
    options: [
      { value: 'food', label: 'Accommodation and Food Services' },
      { value: 'finance', label: 'Accounting, Finance and Insurance' },
      { value: 'support', label: 'Administrative and Support Services' },
      {
        value: 'agriculture',
        label: 'Agriculture, Forestry, Fishing and Hunting'
      },
      {
        value: 'vehicle',
        label: 'All Automotive and Vehicular Products and Services'
      },
      {
        value: 'arts',
        label: 'Arts, Recreation, Entertainment, and Amusement'
      },
      { value: 'chemical', label: 'Chemical, Oil and Gas Industry' },
      { value: 'construction', label: 'Construction and Land Services' },
      {
        value: 'electronic',
        label: 'Electronic / Computer Manufacturing and Services'
      },
      { value: 'health', label: 'Health Care and Social Assistance' },
      {
        value: 'maintenance',
        label: 'Janitorial, Repair and Maintenance Service'
      },
      { value: 'mail', label: 'Mail, Courier and Warehousing Services' },
      { value: 'management', label: 'Management of Companies and Enterprises' },
      { value: 'manufacturing', label: 'Manufacturing' },
      { value: 'mininig', label: 'Mining and Quarrying & Support Servcies' },
      { value: 'other', label: 'Other Services(except Public Administration)' },
      { value: 'tech', label: 'Professional and Technical Services' },
      { value: 'administration', label: 'Public Administration' },
      {
        value: 'communication',
        label: 'Publishers and Information / Communication Services'
      },
      { value: 'rental', label: 'Rentals, Leasing and Real Estate Services' },
      { value: 'retail', label: 'Retail Business' },
      { value: 'education', label: 'Training and Educational Services' },
      {
        value: 'transportation',
        label: 'Transportation and Support Services(Excluding Automobiles)'
      },
      { value: 'utilities', label: 'Utilities' }
    ]
  }
};

export const applicationLinks = {
  ein: '#',
  duns: 'https://www.dnb.com/duns-number/get-a-duns.html'
};

export const sliderData = {
  introduction: 2,
  company: 3,
  financial: 3,
  terms: 1,
  profile: 2
};

export const sliderTitles = {
  introduction: 'Getting Started',
  company: 'Company Profile',
  financial: 'Financial Information',
  terms: 'Terms and Conditions',
  profile: 'Profile'
};
