import React from 'react';
//import styled from 'styled-components';
//import PropTypes from 'prop-types';
import PageTitle from 'components/PageTitle';

class GlossaryPage extends React.Component {
  render() {
    return (
      <React.Fragment>
        <PageTitle>GLOSSARY</PageTitle>
      </React.Fragment>
    );
  }
}

GlossaryPage.propTypes = {};

export default GlossaryPage;
