import React from 'react';
//import styled from 'styled-components';
//import PropTypes from 'prop-types';
import PageTitle from 'components/PageTitle';

class FilesPage extends React.Component {
  render() {
    return (
      <React.Fragment>
        <PageTitle>FILES</PageTitle>
      </React.Fragment>
    );
  }
}

FilesPage.propTypes = {};

export default FilesPage;
