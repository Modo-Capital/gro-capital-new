import styled from 'styled-components';

const SupportSection = styled.div`
  h3 {
    color: #616161;
    margin-top: 10px;
    margin-bottom: 3px;
  }

  a {
    color: #98C25F;
    font-size: 13px;
    font-weight: 500;
    text-decoration: none;
    &:hover {
      color: #98c25f;
    }
  }
`;

SupportSection.displayName = 'SupportSection';

export default SupportSection;
