import React from 'react';
//import styled from 'styled-components';
//import PropTypes from 'prop-types';
import PageTitle from 'components/PageTitle';

class TeamListPage extends React.Component {
  render() {
    return (
      <React.Fragment>
        <PageTitle>TEAM LIST</PageTitle>
      </React.Fragment>
    );
  }
}

TeamListPage.propTypes = {};

export default TeamListPage;
