import React from 'react';
//import styled from 'styled-components';
//import PropTypes from 'prop-types';

const AboutUsPage = () => {
    return (
      <React.Fragment>AboutUsPage</React.Fragment>
    );
};

AboutUsPage.propTypes = {};

export default AboutUsPage;