// import React from 'react';
// import { mount } from 'enzyme';
// import NotificationsPage from '../pages/NotificationsPage';

describe('<NotificationsPage />', () => {
  it('Testing NorificationPage', () => {
    // const wrapper = mount(<NotificationsPage/>);
    // expect(wrapper);
  });
});
